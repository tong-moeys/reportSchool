'use client';

import React, { useRef, useState, useEffect } from 'react';
import {
  Printer,
  FileSpreadsheet,
  FileJson,
  Cloud,
  Upload,
  RotateCcw,
  Eye,
  Users,
  MoreVertical,
  ZoomIn,
  ZoomOut,
  Maximize2,
  CheckCircle2,
  School,
  X
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { ReportState } from '@/lib/report-data';

interface ReportToolbarProps {
  data: ReportState;
  onUpdate: (data: ReportState) => void;
  onReset: () => void;
  activeTab: 'all' | 'page1' | 'page2' | 'page3' | 'teachers';
  setActiveTab: (tab: 'all' | 'page1' | 'page2' | 'page3' | 'teachers') => void;
  statusMsg: { text: string; isOk: boolean } | null;
  onSaveCloud: () => void;
  zoomLevel?: number;
  setZoomLevel?: (zoom: number) => void;
}

export const ReportToolbar: React.FC<ReportToolbarProps> = ({
  data,
  onUpdate,
  onReset,
  activeTab,
  setActiveTab,
  statusMsg,
  onSaveCloud,
  zoomLevel = 1,
  setZoomLevel,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showActionsMenu, setShowActionsMenu] = useState(false);
  const [showZoomMenu, setShowZoomMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const zoomRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowActionsMenu(false);
      }
      if (zoomRef.current && !zoomRef.current.contains(e.target as Node)) {
        setShowZoomMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePrint = () => {
    setShowActionsMenu(false);
    const prevTab = activeTab;
    setActiveTab('all');
    setTimeout(() => {
      window.print();
      if (prevTab !== 'all') {
        setActiveTab(prevTab);
      }
    }, 200);
  };

  const handleExportJson = () => {
    setShowActionsMenu(false);
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Educational_Report_Rok_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportXlsx = () => {
    setShowActionsMenu(false);
    const wb = XLSX.utils.book_new();

    // Sheet 1: Quantitative & Results Summary
    const page1Data: (string | number)[][] = [
      ['ព្រះរាជាណាចក្រកម្ពុជា ជាតិ សាសនា ព្រះមហាក្សត្រ'],
      ['របាយការណ៍បូកសរុបលទ្ធផលការងារអប់រំ ផ្នែកបឋមសិក្សា (ឆមាសទី១ ២០២៥-២០២៦)'],
      ['សាលាបឋមសិក្សា រោគ - កម្រងស្ពានស្រែង'],
      [],
      ['I. បម្រែបម្រួលផ្នែកបរិមាណ - សាលារៀន'],
      ['កម្រងសាលា', data.clusterCount, 'ទីប្រជុំជន', data.urbanCount, 'ធម្មតា', data.normalCount, 'ដាច់ស្រយាល', data.remoteCount, 'បន្ទប់សរុប', data.totalRooms],
      [],
      ['ប្រៀបធៀបចំនួនសិស្ស បវេសនកាល'],
      ['ថ្នាក់ទី', 'សិស្សសរុប', 'ស្រី', 'ការប្រែប្រួល', 'មូលហេតុ', 'ចំនួន'],
    ];

    data.gradeComparisons.forEach((g) => {
      page1Data.push([`ថ្នាក់ទី${g.grade}`, g.total, g.female, g.changeCount, g.reason, g.causeCount]);
    });

    page1Data.push([]);
    page1Data.push(['II. លទ្ធផលសិក្សាឆមាសទី១']);
    page1Data.push(['ថ្នាក់ទី', 'សិស្សឆមាស១ សរុប', 'ស្រី', 'បវេសនកាល សរុប', 'ស្រី', 'ជាប់ សរុប', 'ស្រី', 'ធ្លាក់ សរុប', 'ស្រី']);
    data.results.forEach((r) => {
      page1Data.push([`ថ្នាក់ទី${r.grade}`, r.s1Total, r.s1Female, r.bvesTotal, r.bvesFemale, r.passTotal, r.passFemale, r.failTotal, r.failFemale]);
    });

    const ws1 = XLSX.utils.aoa_to_sheet(page1Data);
    XLSX.utils.book_append_sheet(wb, ws1, 'ទំព័រ១_បូកសរុប');

    // Sheet 2: Staff list
    const staffData: (string | number)[][] = [
      ['បញ្ជីរាយនាមបុគ្គលិក ឆមាសទី១'],
      ['ល.រ', 'នាមត្រកូល-នាម', 'ភេទ', 'ក្របខ័ណ្ឌ', 'កម្រិតវប្បធម៌', 'មុខងារ/ថ្នាក់', 'សិស្សសរុប', 'ស្រី', 'ទូរស័ព្ទ'],
    ];
    data.adminStaff.forEach((s) => {
      staffData.push([s.no, s.name, s.gender, s.framework, s.education, s.roleOrGrade, '-', '-', s.phone]);
    });
    data.teachingStaff.forEach((s) => {
      staffData.push([s.no, s.name, s.gender, s.framework, s.education, `ថ្នាក់ទី${s.roleOrGrade}`, s.studentsTotal || 0, s.studentsFemale || 0, s.phone]);
    });

    const ws2 = XLSX.utils.aoa_to_sheet(staffData);
    XLSX.utils.book_append_sheet(wb, ws2, 'ទំព័រ៣_បុគ្គលិក');

    XLSX.writeFile(wb, `Educational_Report_Rok_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setShowActionsMenu(false);
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.name.endsWith('.json')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed.gradeComparisons && parsed.results) {
            onUpdate(parsed);
          } else {
            alert('ឯកសារ JSON មិនត្រឹមត្រូវតាមទម្រង់របាយការណ៍ទេ!');
          }
        } catch {
          alert('មិនអាចអានឯកសារ JSON បានទេ!');
        }
      };
      reader.readAsText(file);
    } else {
      alert('សូមជ្រើសរើសឯកសារ JSON របាយការណ៍!');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const zoomOptions = [
    { label: 'សមស្រប (Fit)', value: 0.8 },
    { label: '៦៥%', value: 0.65 },
    { label: '៨០%', value: 0.8 },
    { label: '១០០% (ដើម)', value: 1 },
    { label: '១១៥%', value: 1.15 },
  ];

  return (
    <header className="no-print sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-xs border-b border-slate-200">
      {/* Top Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 sm:py-2.5 flex items-center justify-between gap-2">
        {/* School Branding & Title */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0 shadow-xs">
            <School className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                សាលាបឋមសិក្សា រោគ
              </span>
              <span className="hidden sm:inline-block px-2 py-0.2 text-[10px] font-medium bg-blue-50 text-blue-700 border border-blue-200 rounded-full">
                ឆមាសទី១ ២០២៥-២០២៦
              </span>
            </div>
            <p className="text-[10px] text-slate-500 truncate hidden xs:block">
              កម្រងស្ពានស្រែង · ស្រុកភ្នំស្រុក
            </p>
          </div>
        </div>

        {/* Right Header Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Status Message Notification */}
          {statusMsg && (
            <div
              className={`hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                statusMsg.isOk ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span className="truncate max-w-[180px]">{statusMsg.text}</span>
            </div>
          )}

          {/* Zoom Controller */}
          {setZoomLevel && (
            <div className="relative" ref={zoomRef}>
              <button
                type="button"
                onClick={() => setShowZoomMenu((prev) => !prev)}
                className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 active:scale-95 transition"
                title="ពង្រីក/បង្រួមទំហំឯកសារ (Zoom)"
              >
                <Maximize2 className="w-3.5 h-3.5 text-slate-600" />
                <span className="text-[11px] font-semibold">{Math.round(zoomLevel * 100)}%</span>
              </button>

              {showZoomMenu && (
                <div className="absolute right-0 mt-1 w-40 bg-white rounded-xl shadow-lg border border-slate-200 py-1 z-50 text-xs">
                  <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                    ទំហំបង្ហាញ (Zoom)
                  </div>
                  {zoomOptions.map((opt) => (
                    <button
                      key={opt.label}
                      type="button"
                      onClick={() => {
                        setZoomLevel(opt.value);
                        setShowZoomMenu(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-blue-50 transition flex items-center justify-between ${
                        Math.abs(zoomLevel - opt.value) < 0.05
                          ? 'font-bold text-blue-700 bg-blue-50/70'
                          : 'text-slate-700'
                      }`}
                    >
                      <span>{opt.label}</span>
                      {Math.abs(zoomLevel - opt.value) < 0.05 && (
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                      )}
                    </button>
                  ))}
                  <div className="border-t border-slate-100 mt-1 pt-1 flex items-center justify-around px-2">
                    <button
                      type="button"
                      onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                      className="p-1 text-slate-600 hover:text-blue-700"
                      title="បង្រួម"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setZoomLevel(1)}
                      className="px-1.5 py-0.5 text-[10px] text-slate-600 hover:text-blue-700 rounded bg-slate-100"
                    >
                      ១០០%
                    </button>
                    <button
                      type="button"
                      onClick={() => setZoomLevel(Math.min(1.4, zoomLevel + 0.1))}
                      className="p-1 text-slate-600 hover:text-blue-700"
                      title="ពង្រីក"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick Print Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition shadow-2xs"
            title="បោះពុម្ព ឬរក្សាទុកជា PDF (Print)"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">បោះពុម្ព (Print)</span>
          </button>

          {/* Quick Cloud Save Button (Visible on md screens) */}
          <button
            type="button"
            onClick={onSaveCloud}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 active:scale-95 transition"
            title="រក្សាទុកទិន្នន័យក្នុង Cloud Firestore"
          >
            <Cloud className="w-3.5 h-3.5 text-blue-600" />
            <span>Save Cloud</span>
          </button>

          {/* Actions Dropdown Button (Contains XLSX, JSON, Cloud, Import, Reset) */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setShowActionsMenu((prev) => !prev)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 active:scale-95 transition border border-slate-200"
              title="សកម្មភាពផ្សេងៗ"
            >
              <MoreVertical className="w-4 h-4 text-slate-600" />
              <span className="text-xs font-semibold">សកម្មភាព</span>
            </button>

            {showActionsMenu && (
              <div className="absolute right-0 mt-1 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-xs">
                <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  នាំចេញ & នាំចូលទិន្នន័យ
                </div>

                <button
                  type="button"
                  onClick={handleExportXlsx}
                  className="w-full text-left px-3 py-2 text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition flex items-center gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span>ទាញយកជា Excel (.xlsx)</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportJson}
                  className="w-full text-left px-3 py-2 text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition flex items-center gap-2"
                >
                  <FileJson className="w-4 h-4 text-amber-600" />
                  <span>ទាញយកទិន្នន័យ JSON</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowActionsMenu(false);
                    onSaveCloud();
                  }}
                  className="w-full text-left px-3 py-2 text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition flex items-center gap-2"
                >
                  <Cloud className="w-4 h-4 text-blue-600" />
                  <span>រក្សាទុកក្នុង Cloud Firestore</span>
                </button>

                <label
                  htmlFor="file-importer-menu"
                  className="w-full text-left px-3 py-2 text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition flex items-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-purple-600" />
                  <span>បញ្ចូលឯកសារ JSON (Import)</span>
                  <input
                    id="file-importer-menu"
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>

                <div className="border-t border-slate-100 my-1" />

                <button
                  type="button"
                  onClick={() => {
                    setShowActionsMenu(false);
                    onReset();
                  }}
                  className="w-full text-left px-3 py-2 text-rose-600 hover:bg-rose-50 transition flex items-center gap-2 font-medium"
                >
                  <RotateCcw className="w-4 h-4 text-rose-500" />
                  <span>កំណត់ទិន្នន័យដើមឡើងវិញ</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tier 2: Horizontal Scrollable Tabs */}
      <div className="border-t border-slate-200/80 bg-slate-50/90 px-2 sm:px-4 py-1.5">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1.5 ${
              activeTab === 'all'
                ? 'bg-blue-700 text-white font-semibold shadow-2xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-100'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>ទំព័រទាំងអស់ (Print)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('page1')}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition ${
              activeTab === 'page1'
                ? 'bg-blue-700 text-white font-semibold shadow-2xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-100'
            }`}
          >
            ទំព័រ ១ (បូកសរុប)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('page2')}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition ${
              activeTab === 'page2'
                ? 'bg-blue-700 text-white font-semibold shadow-2xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-100'
            }`}
          >
            ទំព័រ ២ (តារាងស្ថិតិ)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('page3')}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition ${
              activeTab === 'page3'
                ? 'bg-blue-700 text-white font-semibold shadow-2xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-100'
            }`}
          >
            ទំព័រ ៣ (បុគ្គលិក)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('teachers')}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1.5 ${
              activeTab === 'teachers'
                ? 'bg-indigo-600 text-white font-semibold shadow-2xs'
                : 'bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 font-medium'
            }`}
            title="ទិន្នន័យគ្រូបង្រៀនលម្អិត (Cloud Firestore)"
          >
            <Users className="w-3.5 h-3.5 text-indigo-500" />
            <span>ទិន្នន័យគ្រូ (Teacher Data)</span>
          </button>
        </div>
      </div>
    </header>
  );
};
