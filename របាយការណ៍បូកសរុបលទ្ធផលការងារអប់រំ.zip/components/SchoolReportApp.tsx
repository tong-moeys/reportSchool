'use client';

import React, { useState, useEffect } from 'react';
import { initialReportData, ReportState } from '@/lib/report-data';
import { ReportToolbar } from '@/components/ReportToolbar';
import { Page1Report } from '@/components/Page1Report';
import { Page2Stats } from '@/components/Page2Stats';
import { Page3Staff } from '@/components/Page3Staff';
import { TeacherDataManager } from '@/components/TeacherDataManager';
import { subscribeSchoolReport, saveSchoolReportToFirestore } from '@/lib/firestore-service';

const STORAGE_KEY = 'school_report_rok_data_v1';

export function SchoolReportApp() {
  const [data, setData] = useState<ReportState>(() => {
    if (typeof window === 'undefined') {
      return initialReportData;
    }
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.gradeComparisons) {
          return parsed;
        }
      }
    } catch {
      // Ignore parse error, use default
    }
    return initialReportData;
  });

  const [activeTab, setActiveTab] = useState<'all' | 'page1' | 'page2' | 'page3' | 'teachers'>('all');
  const [statusMsg, setStatusMsg] = useState<{ text: string; isOk: boolean } | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Subscribe to real-time Firestore synchronization for the primary school report
  useEffect(() => {
    const unsub = subscribeSchoolReport(
      (cloudData) => {
        if (cloudData && cloudData.gradeComparisons) {
          setData(cloudData);
        }
      },
      (err) => {
        console.warn('Firestore report subscription warning:', err);
      }
    );
    return () => unsub();
  }, []);

  // Autosave to local storage when state changes
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // Storage full or unavailable
    }
  }, [data]);

  const handleReset = () => {
    if (typeof window !== 'undefined' && window.confirm('តើអ្នកពិតជាចង់កំណត់ទិន្នន័យទាំងអស់ឡើងវិញមែនទេ?')) {
      setData(initialReportData);
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        // ignore
      }
      saveSchoolReportToFirestore(initialReportData).catch(console.warn);
      showStatus('បានកំណត់ទិន្នន័យដើមឡើងវិញ', true);
    }
  };

  const showStatus = (text: string, isOk: boolean) => {
    setStatusMsg({ text, isOk });
    setTimeout(() => {
      setStatusMsg(null);
    }, 4000);
  };

  const handleSaveCloud = async () => {
    try {
      showStatus('កំពុងរក្សាទុកក្នុង Cloud Firestore...', true);
      await saveSchoolReportToFirestore(data);
      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      }
      showStatus('✔ បានរក្សាទុកក្នុង Firestore ជោគជ័យ!', true);
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Error';
      showStatus(`បរាជ័យក្នុងការរក្សាទុក: ${err}`, false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-100/80 pb-16 print:bg-white print:pb-0 font-sans">
      {/* Top Application Toolbar */}
      <ReportToolbar
        data={data}
        onUpdate={(newData) => {
          setData(newData);
          saveSchoolReportToFirestore(newData).catch(console.warn);
          showStatus('បានផ្ទុកទិន្នន័យជោគជ័យ!', true);
        }}
        onReset={handleReset}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        statusMsg={statusMsg}
        onSaveCloud={handleSaveCloud}
        zoomLevel={zoomLevel}
        setZoomLevel={setZoomLevel}
      />

      {/* Main Content Area */}
      <div
        className={activeTab === 'teachers' ? 'w-full px-2 sm:px-6 py-4' : 'max-w-6xl mx-auto px-2 sm:px-4 print:p-0 print:m-0'}
        style={zoomLevel !== 1 && activeTab !== 'teachers' ? { zoom: zoomLevel } : undefined}
      >
        {/* Teacher Data Management View */}
        {activeTab === 'teachers' && (
          <TeacherDataManager />
        )}

        {/* Page 1 */}
        {(activeTab === 'all' || activeTab === 'page1') && (
          <div className="page-break-after">
            <Page1Report data={data} onChange={setData} />
          </div>
        )}

        {/* Page 2 */}
        {(activeTab === 'all' || activeTab === 'page2') && (
          <div className="page-break-after">
            <Page2Stats data={data} onChange={setData} />
          </div>
        )}

        {/* Page 3 */}
        {(activeTab === 'all' || activeTab === 'page3') && (
          <div>
            <Page3Staff data={data} onChange={setData} />
          </div>
        )}
      </div>
    </main>
  );
}
